package Modelos;

public class Prontuario {
    private int idProntuario;
    private Paciente paciente;
    private ListaSimples listaSintomas;
    private ListaSimples listaMedicamentos;
    private String diagnostico;
    private String observacoes;

    public Prontuario(int idProntuario, Paciente paciente) {
        this.idProntuario = idProntuario;
        this.paciente = paciente;
        this.listaSintomas = new ListaSimples();
        this.listaMedicamentos = new ListaSimples();
        this.diagnostico = "Aguardando atendimento";
        this.observacoes = "";
    }

    public void adicionarSintomas(String sintoma) {
        listaSintomas.adicionar(sintoma);
    }

    public void adicionarMedicamento(String medicamento) {
        listaMedicamentos.adicionar(medicamento);
    }

    public void registrarDiagnostico(String diagnostico, String obs) {
        this.diagnostico = diagnostico;
        this.observacoes = obs;
    }

    public String gerarTexto() {
        String texto = "";
        texto += "=== PRONTUÁRIO Nº " + idProntuario + " ===\n";
        texto += "Paciente: " + paciente.getNome() + "\n";
        texto += "CPF: " + paciente.getCpf() + "\n";
        texto += "Prioridade: " + paciente.getPrioridade() + "\n\n";
        texto += "Sintomas:\n" + listaSintomas.listarTexto() + "\n";
        texto += "Medicamentos:\n" + listaMedicamentos.listarTexto() + "\n";
        texto += "Diagnóstico: " + diagnostico + "\n";
        texto += "Observações: " + observacoes + "\n";
        texto += "===============================\n";
        return texto;
    }

    public void exibirProntuario() {
        System.out.println(gerarTexto());
    }
}
package Modelos;

import Estruturas.Listas.ListaPacientes;

public class UnidadeAtendimento {
    private String nome, senha;

    private ListaPacientes pacientes;
    private Fila fila;
    private PilhaHistorico historico;

    private Paciente pacienteEmAtendimento;

    private NoProntuario inicioProntuarios;
    private NoProntuario fimProntuarios;
    private NoProntuario prontuarioAtual;

    private int contadorProntuarios;

    private static class NoProntuario {
        String texto;
        NoProntuario anterior;
        NoProntuario proximo;

        public NoProntuario(String texto) {
            this.texto = texto;
            this.anterior = null;
            this.proximo = null;
        }
    }

    public UnidadeAtendimento(String nome, String senha) {
        this.nome = nome;
        this.senha = senha;

        this.pacientes = new ListaPacientes();
        this.fila = new Fila();
        this.historico = new PilhaHistorico();

        this.pacienteEmAtendimento = null;

        this.inicioProntuarios = null;
        this.fimProntuarios = null;
        this.prontuarioAtual = null;

        this.contadorProntuarios = 0;
    }

    public String getNome() {
        return nome;
    }

    public String getSenha() {
        return senha;
    }

    public ListaPacientes getPacientes() {
        return pacientes;
    }

    public Fila getFila() {
        return fila;
    }

    public PilhaHistorico getHistorico() {
        return historico;
    }

    public Paciente getPacienteEmAtendimento() {
        return pacienteEmAtendimento;
    }

    public boolean temPacienteEmAtendimento() {
        return pacienteEmAtendimento != null;
    }

    public void novoPaciente(Paciente paciente) {
        pacientes.inserir(paciente);
    }

    public void RegistrarChegada(Paciente paciente) {
        paciente.setStatusAtendimento("Aguardando na fila");
        paciente.cadastrar(pacientes);
    }

    public String listarPacientesTexto() {
        return pacientes.listarPacientesTexto();
    }

    public String exibirFilaTexto() {
        return fila.exibirFilaTexto();
    }

    public Paciente chamarProximoPaciente() {
        if (pacienteEmAtendimento != null) {
            return null;
        }

        pacienteEmAtendimento = fila.desenfileirar();

        if (pacienteEmAtendimento != null) {
            pacienteEmAtendimento.setStatusAtendimento("Em atendimento");
        }

        return pacienteEmAtendimento;
    }

    public Paciente finalizarAtendimento(String diagnostico, String observacoes, String medicamentos) {
        if (pacienteEmAtendimento == null) {
            return null;
        }

        pacienteEmAtendimento.setStatusAtendimento("Finalizado");
        historico.push(pacienteEmAtendimento);

        contadorProntuarios++;

        adicionarProntuario(
                "=== PRONTUÁRIO Nº " + contadorProntuarios + " ===\n"
                + "Paciente: " + pacienteEmAtendimento.getNome() + "\n"
                + "ID: " + pacienteEmAtendimento.getId() + "\n"
                + "Idade: " + pacienteEmAtendimento.getIdade() + "\n"
                + "CPF: " + pacienteEmAtendimento.getCpf() + "\n"
                + "Prioridade: " + pacienteEmAtendimento.getPrioridade() + "\n"
                + "Sintomas: " + pacienteEmAtendimento.getSintomas() + "\n"
                + "Diagnóstico: " + (diagnostico == null || diagnostico.trim().isEmpty() ? "Não informado" : diagnostico) + "\n"
                + "Medicamentos: " + (medicamentos == null || medicamentos.trim().isEmpty() ? "Nenhum" : medicamentos) + "\n"
                + "Observações: " + (observacoes == null || observacoes.trim().isEmpty() ? "Nenhuma" : observacoes) + "\n"
                + "===========================\n"
        );

        Paciente finalizado = pacienteEmAtendimento;
        pacienteEmAtendimento = null;

        return finalizado;
    }

    public String exibirHistoricoTexto() {
        return historico.listar();
    }

    public String exibirPacienteAtualTexto() {
        if (pacienteEmAtendimento == null) {
            return "Nenhum paciente em atendimento.";
        }

        Paciente p = pacienteEmAtendimento;

        return "Paciente em atendimento:\n\n"
                + "ID: " + p.getId() + "\n"
                + "Nome: " + p.getNome() + "\n"
                + "Idade: " + p.getIdade() + "\n"
                + "CPF: " + p.getCpf() + "\n"
                + "Prioridade: " + p.getPrioridade() + "\n"
                + "Sintomas: " + p.getSintomas() + "\n"
                + "Status: " + p.getStatusAtendimento();
    }

    private void adicionarProntuario(String texto) {
        NoProntuario novo = new NoProntuario(texto);

        if (inicioProntuarios == null) {
            inicioProntuarios = novo;
            fimProntuarios = novo;
        } else {
            fimProntuarios.proximo = novo;
            novo.anterior = fimProntuarios;
            fimProntuarios = novo;
        }

        prontuarioAtual = fimProntuarios;
    }

    public boolean temProntuarios() {
        return inicioProntuarios != null;
    }

    public String abrirPrimeiroProntuarioTexto() {
        if (!temProntuarios()) {
            return "Nenhum prontuário finalizado ainda.";
        }

        prontuarioAtual = inicioProntuarios;
        return prontuarioAtual.texto;
    }

    public String abrirUltimoProntuarioTexto() {
        if (!temProntuarios()) {
            return "Nenhum prontuário finalizado ainda.";
        }

        prontuarioAtual = fimProntuarios;
        return prontuarioAtual.texto;
    }

    public String avancarProntuarioTexto() {
        if (!temProntuarios()) {
            return "Nenhum prontuário finalizado ainda.";
        }

        if (prontuarioAtual == null) {
            prontuarioAtual = inicioProntuarios;
            return prontuarioAtual.texto;
        }

        if (prontuarioAtual.proximo == null) {
            return "Você já está no último prontuário.\n\n" + prontuarioAtual.texto;
        }

        prontuarioAtual = prontuarioAtual.proximo;
        return prontuarioAtual.texto;
    }

    public String voltarProntuarioTexto() {
        if (!temProntuarios()) {
            return "Nenhum prontuário finalizado ainda.";
        }

        if (prontuarioAtual == null) {
            prontuarioAtual = fimProntuarios;
            return prontuarioAtual.texto;
        }

        if (prontuarioAtual.anterior == null) {
            return "Você já está no primeiro prontuário.\n\n" + prontuarioAtual.texto;
        }

        prontuarioAtual = prontuarioAtual.anterior;
        return prontuarioAtual.texto;
    }
}